/*eslint-disable block-scoped-var, id-length, no-control-regex, no-magic-numbers, no-prototype-builtins, no-redeclare, no-shadow, no-var, sort-vars*/
"use strict";

var $protobuf = require("protobufjs/minimal");

// Common aliases
var $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;

// Exported root namespace
var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});

$root.royale = (function() {

    /**
     * Namespace royale.
     * @exports royale
     * @namespace
     */
    var royale = {};

    /**
     * Direction enum.
     * @name royale.Direction
     * @enum {string}
     * @property {number} UNKNOWN=0 UNKNOWN value
     * @property {number} LEFT=1 LEFT value
     * @property {number} RIGHT=2 RIGHT value
     * @property {number} UP=3 UP value
     * @property {number} DOWN=4 DOWN value
     */
    royale.Direction = (function() {
        var valuesById = {}, values = Object.create(valuesById);
        values[valuesById[0] = "UNKNOWN"] = 0;
        values[valuesById[1] = "LEFT"] = 1;
        values[valuesById[2] = "RIGHT"] = 2;
        values[valuesById[3] = "UP"] = 3;
        values[valuesById[4] = "DOWN"] = 4;
        return values;
    })();

    royale.JoinRequest = (function() {

        /**
         * Properties of a JoinRequest.
         * @memberof royale
         * @interface IJoinRequest
         * @property {string|null} [playerName] JoinRequest playerName
         */

        /**
         * Constructs a new JoinRequest.
         * @memberof royale
         * @classdesc Represents a JoinRequest.
         * @implements IJoinRequest
         * @constructor
         * @param {royale.IJoinRequest=} [properties] Properties to set
         */
        function JoinRequest(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * JoinRequest playerName.
         * @member {string} playerName
         * @memberof royale.JoinRequest
         * @instance
         */
        JoinRequest.prototype.playerName = "";

        /**
         * Creates a new JoinRequest instance using the specified properties.
         * @function create
         * @memberof royale.JoinRequest
         * @static
         * @param {royale.IJoinRequest=} [properties] Properties to set
         * @returns {royale.JoinRequest} JoinRequest instance
         */
        JoinRequest.create = function create(properties) {
            return new JoinRequest(properties);
        };

        /**
         * Encodes the specified JoinRequest message. Does not implicitly {@link royale.JoinRequest.verify|verify} messages.
         * @function encode
         * @memberof royale.JoinRequest
         * @static
         * @param {royale.IJoinRequest} message JoinRequest message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        JoinRequest.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.playerName != null && message.hasOwnProperty("playerName"))
                writer.uint32(/* id 1, wireType 2 =*/10).string(message.playerName);
            return writer;
        };

        /**
         * Encodes the specified JoinRequest message, length delimited. Does not implicitly {@link royale.JoinRequest.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.JoinRequest
         * @static
         * @param {royale.IJoinRequest} message JoinRequest message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        JoinRequest.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a JoinRequest message from the specified reader or buffer.
         * @function decode
         * @memberof royale.JoinRequest
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.JoinRequest} JoinRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        JoinRequest.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.JoinRequest();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.playerName = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a JoinRequest message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.JoinRequest
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.JoinRequest} JoinRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        JoinRequest.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a JoinRequest message.
         * @function verify
         * @memberof royale.JoinRequest
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        JoinRequest.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            if (message.playerName != null && message.hasOwnProperty("playerName"))
                if (!$util.isString(message.playerName))
                    return "playerName: string expected";
            return null;
        };

        /**
         * Creates a JoinRequest message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.JoinRequest
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.JoinRequest} JoinRequest
         */
        JoinRequest.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.JoinRequest)
                return object;
            var message = new $root.royale.JoinRequest();
            if (object.playerName != null)
                message.playerName = String(object.playerName);
            return message;
        };

        /**
         * Creates a plain object from a JoinRequest message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.JoinRequest
         * @static
         * @param {royale.JoinRequest} message JoinRequest
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        JoinRequest.toObject = function toObject(message, options) {
            if (!options)
                options = {};
            var object = {};
            if (options.defaults)
                object.playerName = "";
            if (message.playerName != null && message.hasOwnProperty("playerName"))
                object.playerName = message.playerName;
            return object;
        };

        /**
         * Converts this JoinRequest to JSON.
         * @function toJSON
         * @memberof royale.JoinRequest
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        JoinRequest.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return JoinRequest;
    })();

    royale.JoinResponse = (function() {

        /**
         * Properties of a JoinResponse.
         * @memberof royale
         * @interface IJoinResponse
         * @property {royale.IJoinSuccess|null} [joinSuccess] JoinResponse joinSuccess
         * @property {royale.IJoinFailure|null} [joinFailure] JoinResponse joinFailure
         */

        /**
         * Constructs a new JoinResponse.
         * @memberof royale
         * @classdesc Represents a JoinResponse.
         * @implements IJoinResponse
         * @constructor
         * @param {royale.IJoinResponse=} [properties] Properties to set
         */
        function JoinResponse(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * JoinResponse joinSuccess.
         * @member {royale.IJoinSuccess|null|undefined} joinSuccess
         * @memberof royale.JoinResponse
         * @instance
         */
        JoinResponse.prototype.joinSuccess = null;

        /**
         * JoinResponse joinFailure.
         * @member {royale.IJoinFailure|null|undefined} joinFailure
         * @memberof royale.JoinResponse
         * @instance
         */
        JoinResponse.prototype.joinFailure = null;

        // OneOf field names bound to virtual getters and setters
        var $oneOfFields;

        /**
         * JoinResponse response.
         * @member {"joinSuccess"|"joinFailure"|undefined} response
         * @memberof royale.JoinResponse
         * @instance
         */
        Object.defineProperty(JoinResponse.prototype, "response", {
            get: $util.oneOfGetter($oneOfFields = ["joinSuccess", "joinFailure"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * Creates a new JoinResponse instance using the specified properties.
         * @function create
         * @memberof royale.JoinResponse
         * @static
         * @param {royale.IJoinResponse=} [properties] Properties to set
         * @returns {royale.JoinResponse} JoinResponse instance
         */
        JoinResponse.create = function create(properties) {
            return new JoinResponse(properties);
        };

        /**
         * Encodes the specified JoinResponse message. Does not implicitly {@link royale.JoinResponse.verify|verify} messages.
         * @function encode
         * @memberof royale.JoinResponse
         * @static
         * @param {royale.IJoinResponse} message JoinResponse message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        JoinResponse.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.joinSuccess != null && message.hasOwnProperty("joinSuccess"))
                $root.royale.JoinSuccess.encode(message.joinSuccess, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
            if (message.joinFailure != null && message.hasOwnProperty("joinFailure"))
                $root.royale.JoinFailure.encode(message.joinFailure, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
            return writer;
        };

        /**
         * Encodes the specified JoinResponse message, length delimited. Does not implicitly {@link royale.JoinResponse.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.JoinResponse
         * @static
         * @param {royale.IJoinResponse} message JoinResponse message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        JoinResponse.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a JoinResponse message from the specified reader or buffer.
         * @function decode
         * @memberof royale.JoinResponse
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.JoinResponse} JoinResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        JoinResponse.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.JoinResponse();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.joinSuccess = $root.royale.JoinSuccess.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.joinFailure = $root.royale.JoinFailure.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a JoinResponse message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.JoinResponse
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.JoinResponse} JoinResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        JoinResponse.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a JoinResponse message.
         * @function verify
         * @memberof royale.JoinResponse
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        JoinResponse.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            var properties = {};
            if (message.joinSuccess != null && message.hasOwnProperty("joinSuccess")) {
                properties.response = 1;
                {
                    var error = $root.royale.JoinSuccess.verify(message.joinSuccess);
                    if (error)
                        return "joinSuccess." + error;
                }
            }
            if (message.joinFailure != null && message.hasOwnProperty("joinFailure")) {
                if (properties.response === 1)
                    return "response: multiple values";
                properties.response = 1;
                {
                    var error = $root.royale.JoinFailure.verify(message.joinFailure);
                    if (error)
                        return "joinFailure." + error;
                }
            }
            return null;
        };

        /**
         * Creates a JoinResponse message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.JoinResponse
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.JoinResponse} JoinResponse
         */
        JoinResponse.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.JoinResponse)
                return object;
            var message = new $root.royale.JoinResponse();
            if (object.joinSuccess != null) {
                if (typeof object.joinSuccess !== "object")
                    throw TypeError(".royale.JoinResponse.joinSuccess: object expected");
                message.joinSuccess = $root.royale.JoinSuccess.fromObject(object.joinSuccess);
            }
            if (object.joinFailure != null) {
                if (typeof object.joinFailure !== "object")
                    throw TypeError(".royale.JoinResponse.joinFailure: object expected");
                message.joinFailure = $root.royale.JoinFailure.fromObject(object.joinFailure);
            }
            return message;
        };

        /**
         * Creates a plain object from a JoinResponse message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.JoinResponse
         * @static
         * @param {royale.JoinResponse} message JoinResponse
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        JoinResponse.toObject = function toObject(message, options) {
            if (!options)
                options = {};
            var object = {};
            if (message.joinSuccess != null && message.hasOwnProperty("joinSuccess")) {
                object.joinSuccess = $root.royale.JoinSuccess.toObject(message.joinSuccess, options);
                if (options.oneofs)
                    object.response = "joinSuccess";
            }
            if (message.joinFailure != null && message.hasOwnProperty("joinFailure")) {
                object.joinFailure = $root.royale.JoinFailure.toObject(message.joinFailure, options);
                if (options.oneofs)
                    object.response = "joinFailure";
            }
            return object;
        };

        /**
         * Converts this JoinResponse to JSON.
         * @function toJSON
         * @memberof royale.JoinResponse
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        JoinResponse.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return JoinResponse;
    })();

    royale.GameInfo = (function() {

        /**
         * Properties of a GameInfo.
         * @memberof royale
         * @interface IGameInfo
         */

        /**
         * Constructs a new GameInfo.
         * @memberof royale
         * @classdesc Represents a GameInfo.
         * @implements IGameInfo
         * @constructor
         * @param {royale.IGameInfo=} [properties] Properties to set
         */
        function GameInfo(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * Creates a new GameInfo instance using the specified properties.
         * @function create
         * @memberof royale.GameInfo
         * @static
         * @param {royale.IGameInfo=} [properties] Properties to set
         * @returns {royale.GameInfo} GameInfo instance
         */
        GameInfo.create = function create(properties) {
            return new GameInfo(properties);
        };

        /**
         * Encodes the specified GameInfo message. Does not implicitly {@link royale.GameInfo.verify|verify} messages.
         * @function encode
         * @memberof royale.GameInfo
         * @static
         * @param {royale.IGameInfo} message GameInfo message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        GameInfo.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            return writer;
        };

        /**
         * Encodes the specified GameInfo message, length delimited. Does not implicitly {@link royale.GameInfo.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.GameInfo
         * @static
         * @param {royale.IGameInfo} message GameInfo message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        GameInfo.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a GameInfo message from the specified reader or buffer.
         * @function decode
         * @memberof royale.GameInfo
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.GameInfo} GameInfo
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        GameInfo.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.GameInfo();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a GameInfo message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.GameInfo
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.GameInfo} GameInfo
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        GameInfo.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a GameInfo message.
         * @function verify
         * @memberof royale.GameInfo
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        GameInfo.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            return null;
        };

        /**
         * Creates a GameInfo message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.GameInfo
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.GameInfo} GameInfo
         */
        GameInfo.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.GameInfo)
                return object;
            return new $root.royale.GameInfo();
        };

        /**
         * Creates a plain object from a GameInfo message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.GameInfo
         * @static
         * @param {royale.GameInfo} message GameInfo
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        GameInfo.toObject = function toObject() {
            return {};
        };

        /**
         * Converts this GameInfo to JSON.
         * @function toJSON
         * @memberof royale.GameInfo
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        GameInfo.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return GameInfo;
    })();

    royale.Point = (function() {

        /**
         * Properties of a Point.
         * @memberof royale
         * @interface IPoint
         * @property {number|null} [x] Point x
         * @property {number|null} [y] Point y
         */

        /**
         * Constructs a new Point.
         * @memberof royale
         * @classdesc Represents a Point.
         * @implements IPoint
         * @constructor
         * @param {royale.IPoint=} [properties] Properties to set
         */
        function Point(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * Point x.
         * @member {number} x
         * @memberof royale.Point
         * @instance
         */
        Point.prototype.x = 0;

        /**
         * Point y.
         * @member {number} y
         * @memberof royale.Point
         * @instance
         */
        Point.prototype.y = 0;

        /**
         * Creates a new Point instance using the specified properties.
         * @function create
         * @memberof royale.Point
         * @static
         * @param {royale.IPoint=} [properties] Properties to set
         * @returns {royale.Point} Point instance
         */
        Point.create = function create(properties) {
            return new Point(properties);
        };

        /**
         * Encodes the specified Point message. Does not implicitly {@link royale.Point.verify|verify} messages.
         * @function encode
         * @memberof royale.Point
         * @static
         * @param {royale.IPoint} message Point message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        Point.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.x != null && message.hasOwnProperty("x"))
                writer.uint32(/* id 1, wireType 0 =*/8).int32(message.x);
            if (message.y != null && message.hasOwnProperty("y"))
                writer.uint32(/* id 2, wireType 0 =*/16).int32(message.y);
            return writer;
        };

        /**
         * Encodes the specified Point message, length delimited. Does not implicitly {@link royale.Point.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.Point
         * @static
         * @param {royale.IPoint} message Point message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        Point.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a Point message from the specified reader or buffer.
         * @function decode
         * @memberof royale.Point
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.Point} Point
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        Point.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.Point();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.x = reader.int32();
                    break;
                case 2:
                    message.y = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a Point message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.Point
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.Point} Point
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        Point.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a Point message.
         * @function verify
         * @memberof royale.Point
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        Point.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            if (message.x != null && message.hasOwnProperty("x"))
                if (!$util.isInteger(message.x))
                    return "x: integer expected";
            if (message.y != null && message.hasOwnProperty("y"))
                if (!$util.isInteger(message.y))
                    return "y: integer expected";
            return null;
        };

        /**
         * Creates a Point message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.Point
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.Point} Point
         */
        Point.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.Point)
                return object;
            var message = new $root.royale.Point();
            if (object.x != null)
                message.x = object.x | 0;
            if (object.y != null)
                message.y = object.y | 0;
            return message;
        };

        /**
         * Creates a plain object from a Point message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.Point
         * @static
         * @param {royale.Point} message Point
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        Point.toObject = function toObject(message, options) {
            if (!options)
                options = {};
            var object = {};
            if (options.defaults) {
                object.x = 0;
                object.y = 0;
            }
            if (message.x != null && message.hasOwnProperty("x"))
                object.x = message.x;
            if (message.y != null && message.hasOwnProperty("y"))
                object.y = message.y;
            return object;
        };

        /**
         * Converts this Point to JSON.
         * @function toJSON
         * @memberof royale.Point
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        Point.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return Point;
    })();

    royale.GameState = (function() {

        /**
         * Properties of a GameState.
         * @memberof royale
         * @interface IGameState
         * @property {number|null} [boardWidth] GameState boardWidth
         * @property {number|null} [boardHeight] GameState boardHeight
         * @property {Object.<string,string>|null} [idToName] GameState idToName
         * @property {Array.<royale.IPlayer>|null} [players] GameState players
         * @property {Array.<royale.IPoint>|null} [food] GameState food
         */

        /**
         * Constructs a new GameState.
         * @memberof royale
         * @classdesc Represents a GameState.
         * @implements IGameState
         * @constructor
         * @param {royale.IGameState=} [properties] Properties to set
         */
        function GameState(properties) {
            this.idToName = {};
            this.players = [];
            this.food = [];
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * GameState boardWidth.
         * @member {number} boardWidth
         * @memberof royale.GameState
         * @instance
         */
        GameState.prototype.boardWidth = 0;

        /**
         * GameState boardHeight.
         * @member {number} boardHeight
         * @memberof royale.GameState
         * @instance
         */
        GameState.prototype.boardHeight = 0;

        /**
         * GameState idToName.
         * @member {Object.<string,string>} idToName
         * @memberof royale.GameState
         * @instance
         */
        GameState.prototype.idToName = $util.emptyObject;

        /**
         * GameState players.
         * @member {Array.<royale.IPlayer>} players
         * @memberof royale.GameState
         * @instance
         */
        GameState.prototype.players = $util.emptyArray;

        /**
         * GameState food.
         * @member {Array.<royale.IPoint>} food
         * @memberof royale.GameState
         * @instance
         */
        GameState.prototype.food = $util.emptyArray;

        /**
         * Creates a new GameState instance using the specified properties.
         * @function create
         * @memberof royale.GameState
         * @static
         * @param {royale.IGameState=} [properties] Properties to set
         * @returns {royale.GameState} GameState instance
         */
        GameState.create = function create(properties) {
            return new GameState(properties);
        };

        /**
         * Encodes the specified GameState message. Does not implicitly {@link royale.GameState.verify|verify} messages.
         * @function encode
         * @memberof royale.GameState
         * @static
         * @param {royale.IGameState} message GameState message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        GameState.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.boardWidth != null && message.hasOwnProperty("boardWidth"))
                writer.uint32(/* id 1, wireType 0 =*/8).int32(message.boardWidth);
            if (message.boardHeight != null && message.hasOwnProperty("boardHeight"))
                writer.uint32(/* id 2, wireType 0 =*/16).int32(message.boardHeight);
            if (message.idToName != null && message.hasOwnProperty("idToName"))
                for (var keys = Object.keys(message.idToName), i = 0; i < keys.length; ++i)
                    writer.uint32(/* id 3, wireType 2 =*/26).fork().uint32(/* id 1, wireType 0 =*/8).int32(keys[i]).uint32(/* id 2, wireType 2 =*/18).string(message.idToName[keys[i]]).ldelim();
            if (message.players != null && message.players.length)
                for (var i = 0; i < message.players.length; ++i)
                    $root.royale.Player.encode(message.players[i], writer.uint32(/* id 4, wireType 2 =*/34).fork()).ldelim();
            if (message.food != null && message.food.length)
                for (var i = 0; i < message.food.length; ++i)
                    $root.royale.Point.encode(message.food[i], writer.uint32(/* id 5, wireType 2 =*/42).fork()).ldelim();
            return writer;
        };

        /**
         * Encodes the specified GameState message, length delimited. Does not implicitly {@link royale.GameState.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.GameState
         * @static
         * @param {royale.IGameState} message GameState message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        GameState.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a GameState message from the specified reader or buffer.
         * @function decode
         * @memberof royale.GameState
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.GameState} GameState
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        GameState.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.GameState(), key;
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.boardWidth = reader.int32();
                    break;
                case 2:
                    message.boardHeight = reader.int32();
                    break;
                case 3:
                    reader.skip().pos++;
                    if (message.idToName === $util.emptyObject)
                        message.idToName = {};
                    key = reader.int32();
                    reader.pos++;
                    message.idToName[key] = reader.string();
                    break;
                case 4:
                    if (!(message.players && message.players.length))
                        message.players = [];
                    message.players.push($root.royale.Player.decode(reader, reader.uint32()));
                    break;
                case 5:
                    if (!(message.food && message.food.length))
                        message.food = [];
                    message.food.push($root.royale.Point.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a GameState message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.GameState
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.GameState} GameState
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        GameState.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a GameState message.
         * @function verify
         * @memberof royale.GameState
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        GameState.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            if (message.boardWidth != null && message.hasOwnProperty("boardWidth"))
                if (!$util.isInteger(message.boardWidth))
                    return "boardWidth: integer expected";
            if (message.boardHeight != null && message.hasOwnProperty("boardHeight"))
                if (!$util.isInteger(message.boardHeight))
                    return "boardHeight: integer expected";
            if (message.idToName != null && message.hasOwnProperty("idToName")) {
                if (!$util.isObject(message.idToName))
                    return "idToName: object expected";
                var key = Object.keys(message.idToName);
                for (var i = 0; i < key.length; ++i) {
                    if (!$util.key32Re.test(key[i]))
                        return "idToName: integer key{k:int32} expected";
                    if (!$util.isString(message.idToName[key[i]]))
                        return "idToName: string{k:int32} expected";
                }
            }
            if (message.players != null && message.hasOwnProperty("players")) {
                if (!Array.isArray(message.players))
                    return "players: array expected";
                for (var i = 0; i < message.players.length; ++i) {
                    var error = $root.royale.Player.verify(message.players[i]);
                    if (error)
                        return "players." + error;
                }
            }
            if (message.food != null && message.hasOwnProperty("food")) {
                if (!Array.isArray(message.food))
                    return "food: array expected";
                for (var i = 0; i < message.food.length; ++i) {
                    var error = $root.royale.Point.verify(message.food[i]);
                    if (error)
                        return "food." + error;
                }
            }
            return null;
        };

        /**
         * Creates a GameState message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.GameState
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.GameState} GameState
         */
        GameState.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.GameState)
                return object;
            var message = new $root.royale.GameState();
            if (object.boardWidth != null)
                message.boardWidth = object.boardWidth | 0;
            if (object.boardHeight != null)
                message.boardHeight = object.boardHeight | 0;
            if (object.idToName) {
                if (typeof object.idToName !== "object")
                    throw TypeError(".royale.GameState.idToName: object expected");
                message.idToName = {};
                for (var keys = Object.keys(object.idToName), i = 0; i < keys.length; ++i)
                    message.idToName[keys[i]] = String(object.idToName[keys[i]]);
            }
            if (object.players) {
                if (!Array.isArray(object.players))
                    throw TypeError(".royale.GameState.players: array expected");
                message.players = [];
                for (var i = 0; i < object.players.length; ++i) {
                    if (typeof object.players[i] !== "object")
                        throw TypeError(".royale.GameState.players: object expected");
                    message.players[i] = $root.royale.Player.fromObject(object.players[i]);
                }
            }
            if (object.food) {
                if (!Array.isArray(object.food))
                    throw TypeError(".royale.GameState.food: array expected");
                message.food = [];
                for (var i = 0; i < object.food.length; ++i) {
                    if (typeof object.food[i] !== "object")
                        throw TypeError(".royale.GameState.food: object expected");
                    message.food[i] = $root.royale.Point.fromObject(object.food[i]);
                }
            }
            return message;
        };

        /**
         * Creates a plain object from a GameState message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.GameState
         * @static
         * @param {royale.GameState} message GameState
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        GameState.toObject = function toObject(message, options) {
            if (!options)
                options = {};
            var object = {};
            if (options.arrays || options.defaults) {
                object.players = [];
                object.food = [];
            }
            if (options.objects || options.defaults)
                object.idToName = {};
            if (options.defaults) {
                object.boardWidth = 0;
                object.boardHeight = 0;
            }
            if (message.boardWidth != null && message.hasOwnProperty("boardWidth"))
                object.boardWidth = message.boardWidth;
            if (message.boardHeight != null && message.hasOwnProperty("boardHeight"))
                object.boardHeight = message.boardHeight;
            var keys2;
            if (message.idToName && (keys2 = Object.keys(message.idToName)).length) {
                object.idToName = {};
                for (var j = 0; j < keys2.length; ++j)
                    object.idToName[keys2[j]] = message.idToName[keys2[j]];
            }
            if (message.players && message.players.length) {
                object.players = [];
                for (var j = 0; j < message.players.length; ++j)
                    object.players[j] = $root.royale.Player.toObject(message.players[j], options);
            }
            if (message.food && message.food.length) {
                object.food = [];
                for (var j = 0; j < message.food.length; ++j)
                    object.food[j] = $root.royale.Point.toObject(message.food[j], options);
            }
            return object;
        };

        /**
         * Converts this GameState to JSON.
         * @function toJSON
         * @memberof royale.GameState
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        GameState.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return GameState;
    })();

    royale.JoinSuccess = (function() {

        /**
         * Properties of a JoinSuccess.
         * @memberof royale
         * @interface IJoinSuccess
         * @property {royale.IGameInfo|null} [gameInfo] JoinSuccess gameInfo
         * @property {number|null} [playerId] JoinSuccess playerId
         */

        /**
         * Constructs a new JoinSuccess.
         * @memberof royale
         * @classdesc Represents a JoinSuccess.
         * @implements IJoinSuccess
         * @constructor
         * @param {royale.IJoinSuccess=} [properties] Properties to set
         */
        function JoinSuccess(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * JoinSuccess gameInfo.
         * @member {royale.IGameInfo|null|undefined} gameInfo
         * @memberof royale.JoinSuccess
         * @instance
         */
        JoinSuccess.prototype.gameInfo = null;

        /**
         * JoinSuccess playerId.
         * @member {number} playerId
         * @memberof royale.JoinSuccess
         * @instance
         */
        JoinSuccess.prototype.playerId = 0;

        /**
         * Creates a new JoinSuccess instance using the specified properties.
         * @function create
         * @memberof royale.JoinSuccess
         * @static
         * @param {royale.IJoinSuccess=} [properties] Properties to set
         * @returns {royale.JoinSuccess} JoinSuccess instance
         */
        JoinSuccess.create = function create(properties) {
            return new JoinSuccess(properties);
        };

        /**
         * Encodes the specified JoinSuccess message. Does not implicitly {@link royale.JoinSuccess.verify|verify} messages.
         * @function encode
         * @memberof royale.JoinSuccess
         * @static
         * @param {royale.IJoinSuccess} message JoinSuccess message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        JoinSuccess.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.gameInfo != null && message.hasOwnProperty("gameInfo"))
                $root.royale.GameInfo.encode(message.gameInfo, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
            if (message.playerId != null && message.hasOwnProperty("playerId"))
                writer.uint32(/* id 2, wireType 0 =*/16).int32(message.playerId);
            return writer;
        };

        /**
         * Encodes the specified JoinSuccess message, length delimited. Does not implicitly {@link royale.JoinSuccess.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.JoinSuccess
         * @static
         * @param {royale.IJoinSuccess} message JoinSuccess message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        JoinSuccess.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a JoinSuccess message from the specified reader or buffer.
         * @function decode
         * @memberof royale.JoinSuccess
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.JoinSuccess} JoinSuccess
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        JoinSuccess.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.JoinSuccess();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.gameInfo = $root.royale.GameInfo.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.playerId = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a JoinSuccess message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.JoinSuccess
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.JoinSuccess} JoinSuccess
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        JoinSuccess.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a JoinSuccess message.
         * @function verify
         * @memberof royale.JoinSuccess
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        JoinSuccess.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            if (message.gameInfo != null && message.hasOwnProperty("gameInfo")) {
                var error = $root.royale.GameInfo.verify(message.gameInfo);
                if (error)
                    return "gameInfo." + error;
            }
            if (message.playerId != null && message.hasOwnProperty("playerId"))
                if (!$util.isInteger(message.playerId))
                    return "playerId: integer expected";
            return null;
        };

        /**
         * Creates a JoinSuccess message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.JoinSuccess
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.JoinSuccess} JoinSuccess
         */
        JoinSuccess.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.JoinSuccess)
                return object;
            var message = new $root.royale.JoinSuccess();
            if (object.gameInfo != null) {
                if (typeof object.gameInfo !== "object")
                    throw TypeError(".royale.JoinSuccess.gameInfo: object expected");
                message.gameInfo = $root.royale.GameInfo.fromObject(object.gameInfo);
            }
            if (object.playerId != null)
                message.playerId = object.playerId | 0;
            return message;
        };

        /**
         * Creates a plain object from a JoinSuccess message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.JoinSuccess
         * @static
         * @param {royale.JoinSuccess} message JoinSuccess
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        JoinSuccess.toObject = function toObject(message, options) {
            if (!options)
                options = {};
            var object = {};
            if (options.defaults) {
                object.gameInfo = null;
                object.playerId = 0;
            }
            if (message.gameInfo != null && message.hasOwnProperty("gameInfo"))
                object.gameInfo = $root.royale.GameInfo.toObject(message.gameInfo, options);
            if (message.playerId != null && message.hasOwnProperty("playerId"))
                object.playerId = message.playerId;
            return object;
        };

        /**
         * Converts this JoinSuccess to JSON.
         * @function toJSON
         * @memberof royale.JoinSuccess
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        JoinSuccess.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return JoinSuccess;
    })();

    royale.JoinFailure = (function() {

        /**
         * Properties of a JoinFailure.
         * @memberof royale
         * @interface IJoinFailure
         * @property {string|null} [message] JoinFailure message
         */

        /**
         * Constructs a new JoinFailure.
         * @memberof royale
         * @classdesc Represents a JoinFailure.
         * @implements IJoinFailure
         * @constructor
         * @param {royale.IJoinFailure=} [properties] Properties to set
         */
        function JoinFailure(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * JoinFailure message.
         * @member {string} message
         * @memberof royale.JoinFailure
         * @instance
         */
        JoinFailure.prototype.message = "";

        /**
         * Creates a new JoinFailure instance using the specified properties.
         * @function create
         * @memberof royale.JoinFailure
         * @static
         * @param {royale.IJoinFailure=} [properties] Properties to set
         * @returns {royale.JoinFailure} JoinFailure instance
         */
        JoinFailure.create = function create(properties) {
            return new JoinFailure(properties);
        };

        /**
         * Encodes the specified JoinFailure message. Does not implicitly {@link royale.JoinFailure.verify|verify} messages.
         * @function encode
         * @memberof royale.JoinFailure
         * @static
         * @param {royale.IJoinFailure} message JoinFailure message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        JoinFailure.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.message != null && message.hasOwnProperty("message"))
                writer.uint32(/* id 1, wireType 2 =*/10).string(message.message);
            return writer;
        };

        /**
         * Encodes the specified JoinFailure message, length delimited. Does not implicitly {@link royale.JoinFailure.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.JoinFailure
         * @static
         * @param {royale.IJoinFailure} message JoinFailure message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        JoinFailure.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a JoinFailure message from the specified reader or buffer.
         * @function decode
         * @memberof royale.JoinFailure
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.JoinFailure} JoinFailure
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        JoinFailure.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.JoinFailure();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.message = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a JoinFailure message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.JoinFailure
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.JoinFailure} JoinFailure
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        JoinFailure.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a JoinFailure message.
         * @function verify
         * @memberof royale.JoinFailure
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        JoinFailure.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            if (message.message != null && message.hasOwnProperty("message"))
                if (!$util.isString(message.message))
                    return "message: string expected";
            return null;
        };

        /**
         * Creates a JoinFailure message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.JoinFailure
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.JoinFailure} JoinFailure
         */
        JoinFailure.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.JoinFailure)
                return object;
            var message = new $root.royale.JoinFailure();
            if (object.message != null)
                message.message = String(object.message);
            return message;
        };

        /**
         * Creates a plain object from a JoinFailure message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.JoinFailure
         * @static
         * @param {royale.JoinFailure} message JoinFailure
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        JoinFailure.toObject = function toObject(message, options) {
            if (!options)
                options = {};
            var object = {};
            if (options.defaults)
                object.message = "";
            if (message.message != null && message.hasOwnProperty("message"))
                object.message = message.message;
            return object;
        };

        /**
         * Converts this JoinFailure to JSON.
         * @function toJSON
         * @memberof royale.JoinFailure
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        JoinFailure.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return JoinFailure;
    })();

    royale.Player = (function() {

        /**
         * Properties of a Player.
         * @memberof royale
         * @interface IPlayer
         * @property {number|null} [playerId] Player playerId
         * @property {Array.<royale.IPoint>|null} [occupies] Player occupies
         */

        /**
         * Constructs a new Player.
         * @memberof royale
         * @classdesc Represents a Player.
         * @implements IPlayer
         * @constructor
         * @param {royale.IPlayer=} [properties] Properties to set
         */
        function Player(properties) {
            this.occupies = [];
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * Player playerId.
         * @member {number} playerId
         * @memberof royale.Player
         * @instance
         */
        Player.prototype.playerId = 0;

        /**
         * Player occupies.
         * @member {Array.<royale.IPoint>} occupies
         * @memberof royale.Player
         * @instance
         */
        Player.prototype.occupies = $util.emptyArray;

        /**
         * Creates a new Player instance using the specified properties.
         * @function create
         * @memberof royale.Player
         * @static
         * @param {royale.IPlayer=} [properties] Properties to set
         * @returns {royale.Player} Player instance
         */
        Player.create = function create(properties) {
            return new Player(properties);
        };

        /**
         * Encodes the specified Player message. Does not implicitly {@link royale.Player.verify|verify} messages.
         * @function encode
         * @memberof royale.Player
         * @static
         * @param {royale.IPlayer} message Player message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        Player.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.playerId != null && message.hasOwnProperty("playerId"))
                writer.uint32(/* id 1, wireType 0 =*/8).int32(message.playerId);
            if (message.occupies != null && message.occupies.length)
                for (var i = 0; i < message.occupies.length; ++i)
                    $root.royale.Point.encode(message.occupies[i], writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
            return writer;
        };

        /**
         * Encodes the specified Player message, length delimited. Does not implicitly {@link royale.Player.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.Player
         * @static
         * @param {royale.IPlayer} message Player message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        Player.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a Player message from the specified reader or buffer.
         * @function decode
         * @memberof royale.Player
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.Player} Player
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        Player.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.Player();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.playerId = reader.int32();
                    break;
                case 2:
                    if (!(message.occupies && message.occupies.length))
                        message.occupies = [];
                    message.occupies.push($root.royale.Point.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a Player message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.Player
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.Player} Player
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        Player.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a Player message.
         * @function verify
         * @memberof royale.Player
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        Player.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            if (message.playerId != null && message.hasOwnProperty("playerId"))
                if (!$util.isInteger(message.playerId))
                    return "playerId: integer expected";
            if (message.occupies != null && message.hasOwnProperty("occupies")) {
                if (!Array.isArray(message.occupies))
                    return "occupies: array expected";
                for (var i = 0; i < message.occupies.length; ++i) {
                    var error = $root.royale.Point.verify(message.occupies[i]);
                    if (error)
                        return "occupies." + error;
                }
            }
            return null;
        };

        /**
         * Creates a Player message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.Player
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.Player} Player
         */
        Player.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.Player)
                return object;
            var message = new $root.royale.Player();
            if (object.playerId != null)
                message.playerId = object.playerId | 0;
            if (object.occupies) {
                if (!Array.isArray(object.occupies))
                    throw TypeError(".royale.Player.occupies: array expected");
                message.occupies = [];
                for (var i = 0; i < object.occupies.length; ++i) {
                    if (typeof object.occupies[i] !== "object")
                        throw TypeError(".royale.Player.occupies: object expected");
                    message.occupies[i] = $root.royale.Point.fromObject(object.occupies[i]);
                }
            }
            return message;
        };

        /**
         * Creates a plain object from a Player message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.Player
         * @static
         * @param {royale.Player} message Player
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        Player.toObject = function toObject(message, options) {
            if (!options)
                options = {};
            var object = {};
            if (options.arrays || options.defaults)
                object.occupies = [];
            if (options.defaults)
                object.playerId = 0;
            if (message.playerId != null && message.hasOwnProperty("playerId"))
                object.playerId = message.playerId;
            if (message.occupies && message.occupies.length) {
                object.occupies = [];
                for (var j = 0; j < message.occupies.length; ++j)
                    object.occupies[j] = $root.royale.Point.toObject(message.occupies[j], options);
            }
            return object;
        };

        /**
         * Converts this Player to JSON.
         * @function toJSON
         * @memberof royale.Player
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        Player.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return Player;
    })();

    royale.PlayerDisconnected = (function() {

        /**
         * Properties of a PlayerDisconnected.
         * @memberof royale
         * @interface IPlayerDisconnected
         * @property {string|null} [playerName] PlayerDisconnected playerName
         */

        /**
         * Constructs a new PlayerDisconnected.
         * @memberof royale
         * @classdesc Represents a PlayerDisconnected.
         * @implements IPlayerDisconnected
         * @constructor
         * @param {royale.IPlayerDisconnected=} [properties] Properties to set
         */
        function PlayerDisconnected(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * PlayerDisconnected playerName.
         * @member {string} playerName
         * @memberof royale.PlayerDisconnected
         * @instance
         */
        PlayerDisconnected.prototype.playerName = "";

        /**
         * Creates a new PlayerDisconnected instance using the specified properties.
         * @function create
         * @memberof royale.PlayerDisconnected
         * @static
         * @param {royale.IPlayerDisconnected=} [properties] Properties to set
         * @returns {royale.PlayerDisconnected} PlayerDisconnected instance
         */
        PlayerDisconnected.create = function create(properties) {
            return new PlayerDisconnected(properties);
        };

        /**
         * Encodes the specified PlayerDisconnected message. Does not implicitly {@link royale.PlayerDisconnected.verify|verify} messages.
         * @function encode
         * @memberof royale.PlayerDisconnected
         * @static
         * @param {royale.IPlayerDisconnected} message PlayerDisconnected message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        PlayerDisconnected.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.playerName != null && message.hasOwnProperty("playerName"))
                writer.uint32(/* id 1, wireType 2 =*/10).string(message.playerName);
            return writer;
        };

        /**
         * Encodes the specified PlayerDisconnected message, length delimited. Does not implicitly {@link royale.PlayerDisconnected.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.PlayerDisconnected
         * @static
         * @param {royale.IPlayerDisconnected} message PlayerDisconnected message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        PlayerDisconnected.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a PlayerDisconnected message from the specified reader or buffer.
         * @function decode
         * @memberof royale.PlayerDisconnected
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.PlayerDisconnected} PlayerDisconnected
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        PlayerDisconnected.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.PlayerDisconnected();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.playerName = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a PlayerDisconnected message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.PlayerDisconnected
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.PlayerDisconnected} PlayerDisconnected
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        PlayerDisconnected.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a PlayerDisconnected message.
         * @function verify
         * @memberof royale.PlayerDisconnected
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        PlayerDisconnected.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            if (message.playerName != null && message.hasOwnProperty("playerName"))
                if (!$util.isString(message.playerName))
                    return "playerName: string expected";
            return null;
        };

        /**
         * Creates a PlayerDisconnected message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.PlayerDisconnected
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.PlayerDisconnected} PlayerDisconnected
         */
        PlayerDisconnected.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.PlayerDisconnected)
                return object;
            var message = new $root.royale.PlayerDisconnected();
            if (object.playerName != null)
                message.playerName = String(object.playerName);
            return message;
        };

        /**
         * Creates a plain object from a PlayerDisconnected message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.PlayerDisconnected
         * @static
         * @param {royale.PlayerDisconnected} message PlayerDisconnected
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        PlayerDisconnected.toObject = function toObject(message, options) {
            if (!options)
                options = {};
            var object = {};
            if (options.defaults)
                object.playerName = "";
            if (message.playerName != null && message.hasOwnProperty("playerName"))
                object.playerName = message.playerName;
            return object;
        };

        /**
         * Converts this PlayerDisconnected to JSON.
         * @function toJSON
         * @memberof royale.PlayerDisconnected
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        PlayerDisconnected.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return PlayerDisconnected;
    })();

    royale.MoveRequest = (function() {

        /**
         * Properties of a MoveRequest.
         * @memberof royale
         * @interface IMoveRequest
         * @property {royale.Direction|null} [direction] MoveRequest direction
         */

        /**
         * Constructs a new MoveRequest.
         * @memberof royale
         * @classdesc Represents a MoveRequest.
         * @implements IMoveRequest
         * @constructor
         * @param {royale.IMoveRequest=} [properties] Properties to set
         */
        function MoveRequest(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * MoveRequest direction.
         * @member {royale.Direction} direction
         * @memberof royale.MoveRequest
         * @instance
         */
        MoveRequest.prototype.direction = 0;

        /**
         * Creates a new MoveRequest instance using the specified properties.
         * @function create
         * @memberof royale.MoveRequest
         * @static
         * @param {royale.IMoveRequest=} [properties] Properties to set
         * @returns {royale.MoveRequest} MoveRequest instance
         */
        MoveRequest.create = function create(properties) {
            return new MoveRequest(properties);
        };

        /**
         * Encodes the specified MoveRequest message. Does not implicitly {@link royale.MoveRequest.verify|verify} messages.
         * @function encode
         * @memberof royale.MoveRequest
         * @static
         * @param {royale.IMoveRequest} message MoveRequest message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        MoveRequest.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.direction != null && message.hasOwnProperty("direction"))
                writer.uint32(/* id 1, wireType 0 =*/8).int32(message.direction);
            return writer;
        };

        /**
         * Encodes the specified MoveRequest message, length delimited. Does not implicitly {@link royale.MoveRequest.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.MoveRequest
         * @static
         * @param {royale.IMoveRequest} message MoveRequest message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        MoveRequest.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a MoveRequest message from the specified reader or buffer.
         * @function decode
         * @memberof royale.MoveRequest
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.MoveRequest} MoveRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        MoveRequest.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.MoveRequest();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.direction = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a MoveRequest message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.MoveRequest
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.MoveRequest} MoveRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        MoveRequest.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a MoveRequest message.
         * @function verify
         * @memberof royale.MoveRequest
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        MoveRequest.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            if (message.direction != null && message.hasOwnProperty("direction"))
                switch (message.direction) {
                default:
                    return "direction: enum value expected";
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                    break;
                }
            return null;
        };

        /**
         * Creates a MoveRequest message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.MoveRequest
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.MoveRequest} MoveRequest
         */
        MoveRequest.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.MoveRequest)
                return object;
            var message = new $root.royale.MoveRequest();
            switch (object.direction) {
            case "UNKNOWN":
            case 0:
                message.direction = 0;
                break;
            case "LEFT":
            case 1:
                message.direction = 1;
                break;
            case "RIGHT":
            case 2:
                message.direction = 2;
                break;
            case "UP":
            case 3:
                message.direction = 3;
                break;
            case "DOWN":
            case 4:
                message.direction = 4;
                break;
            }
            return message;
        };

        /**
         * Creates a plain object from a MoveRequest message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.MoveRequest
         * @static
         * @param {royale.MoveRequest} message MoveRequest
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        MoveRequest.toObject = function toObject(message, options) {
            if (!options)
                options = {};
            var object = {};
            if (options.defaults)
                object.direction = options.enums === String ? "UNKNOWN" : 0;
            if (message.direction != null && message.hasOwnProperty("direction"))
                object.direction = options.enums === String ? $root.royale.Direction[message.direction] : message.direction;
            return object;
        };

        /**
         * Converts this MoveRequest to JSON.
         * @function toJSON
         * @memberof royale.MoveRequest
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        MoveRequest.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return MoveRequest;
    })();

    royale.ClientEvent = (function() {

        /**
         * Properties of a ClientEvent.
         * @memberof royale
         * @interface IClientEvent
         * @property {royale.IMoveRequest|null} [moveRequest] ClientEvent moveRequest
         * @property {royale.IJoinRequest|null} [joinRequest] ClientEvent joinRequest
         * @property {royale.IPlayerDisconnected|null} [playerDisconnected] ClientEvent playerDisconnected
         */

        /**
         * Constructs a new ClientEvent.
         * @memberof royale
         * @classdesc Represents a ClientEvent.
         * @implements IClientEvent
         * @constructor
         * @param {royale.IClientEvent=} [properties] Properties to set
         */
        function ClientEvent(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * ClientEvent moveRequest.
         * @member {royale.IMoveRequest|null|undefined} moveRequest
         * @memberof royale.ClientEvent
         * @instance
         */
        ClientEvent.prototype.moveRequest = null;

        /**
         * ClientEvent joinRequest.
         * @member {royale.IJoinRequest|null|undefined} joinRequest
         * @memberof royale.ClientEvent
         * @instance
         */
        ClientEvent.prototype.joinRequest = null;

        /**
         * ClientEvent playerDisconnected.
         * @member {royale.IPlayerDisconnected|null|undefined} playerDisconnected
         * @memberof royale.ClientEvent
         * @instance
         */
        ClientEvent.prototype.playerDisconnected = null;

        // OneOf field names bound to virtual getters and setters
        var $oneOfFields;

        /**
         * ClientEvent event.
         * @member {"moveRequest"|"joinRequest"|"playerDisconnected"|undefined} event
         * @memberof royale.ClientEvent
         * @instance
         */
        Object.defineProperty(ClientEvent.prototype, "event", {
            get: $util.oneOfGetter($oneOfFields = ["moveRequest", "joinRequest", "playerDisconnected"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * Creates a new ClientEvent instance using the specified properties.
         * @function create
         * @memberof royale.ClientEvent
         * @static
         * @param {royale.IClientEvent=} [properties] Properties to set
         * @returns {royale.ClientEvent} ClientEvent instance
         */
        ClientEvent.create = function create(properties) {
            return new ClientEvent(properties);
        };

        /**
         * Encodes the specified ClientEvent message. Does not implicitly {@link royale.ClientEvent.verify|verify} messages.
         * @function encode
         * @memberof royale.ClientEvent
         * @static
         * @param {royale.IClientEvent} message ClientEvent message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        ClientEvent.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.moveRequest != null && message.hasOwnProperty("moveRequest"))
                $root.royale.MoveRequest.encode(message.moveRequest, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
            if (message.joinRequest != null && message.hasOwnProperty("joinRequest"))
                $root.royale.JoinRequest.encode(message.joinRequest, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
            if (message.playerDisconnected != null && message.hasOwnProperty("playerDisconnected"))
                $root.royale.PlayerDisconnected.encode(message.playerDisconnected, writer.uint32(/* id 3, wireType 2 =*/26).fork()).ldelim();
            return writer;
        };

        /**
         * Encodes the specified ClientEvent message, length delimited. Does not implicitly {@link royale.ClientEvent.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.ClientEvent
         * @static
         * @param {royale.IClientEvent} message ClientEvent message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        ClientEvent.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a ClientEvent message from the specified reader or buffer.
         * @function decode
         * @memberof royale.ClientEvent
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.ClientEvent} ClientEvent
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        ClientEvent.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.ClientEvent();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.moveRequest = $root.royale.MoveRequest.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.joinRequest = $root.royale.JoinRequest.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.playerDisconnected = $root.royale.PlayerDisconnected.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a ClientEvent message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.ClientEvent
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.ClientEvent} ClientEvent
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        ClientEvent.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a ClientEvent message.
         * @function verify
         * @memberof royale.ClientEvent
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        ClientEvent.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            var properties = {};
            if (message.moveRequest != null && message.hasOwnProperty("moveRequest")) {
                properties.event = 1;
                {
                    var error = $root.royale.MoveRequest.verify(message.moveRequest);
                    if (error)
                        return "moveRequest." + error;
                }
            }
            if (message.joinRequest != null && message.hasOwnProperty("joinRequest")) {
                if (properties.event === 1)
                    return "event: multiple values";
                properties.event = 1;
                {
                    var error = $root.royale.JoinRequest.verify(message.joinRequest);
                    if (error)
                        return "joinRequest." + error;
                }
            }
            if (message.playerDisconnected != null && message.hasOwnProperty("playerDisconnected")) {
                if (properties.event === 1)
                    return "event: multiple values";
                properties.event = 1;
                {
                    var error = $root.royale.PlayerDisconnected.verify(message.playerDisconnected);
                    if (error)
                        return "playerDisconnected." + error;
                }
            }
            return null;
        };

        /**
         * Creates a ClientEvent message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.ClientEvent
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.ClientEvent} ClientEvent
         */
        ClientEvent.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.ClientEvent)
                return object;
            var message = new $root.royale.ClientEvent();
            if (object.moveRequest != null) {
                if (typeof object.moveRequest !== "object")
                    throw TypeError(".royale.ClientEvent.moveRequest: object expected");
                message.moveRequest = $root.royale.MoveRequest.fromObject(object.moveRequest);
            }
            if (object.joinRequest != null) {
                if (typeof object.joinRequest !== "object")
                    throw TypeError(".royale.ClientEvent.joinRequest: object expected");
                message.joinRequest = $root.royale.JoinRequest.fromObject(object.joinRequest);
            }
            if (object.playerDisconnected != null) {
                if (typeof object.playerDisconnected !== "object")
                    throw TypeError(".royale.ClientEvent.playerDisconnected: object expected");
                message.playerDisconnected = $root.royale.PlayerDisconnected.fromObject(object.playerDisconnected);
            }
            return message;
        };

        /**
         * Creates a plain object from a ClientEvent message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.ClientEvent
         * @static
         * @param {royale.ClientEvent} message ClientEvent
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        ClientEvent.toObject = function toObject(message, options) {
            if (!options)
                options = {};
            var object = {};
            if (message.moveRequest != null && message.hasOwnProperty("moveRequest")) {
                object.moveRequest = $root.royale.MoveRequest.toObject(message.moveRequest, options);
                if (options.oneofs)
                    object.event = "moveRequest";
            }
            if (message.joinRequest != null && message.hasOwnProperty("joinRequest")) {
                object.joinRequest = $root.royale.JoinRequest.toObject(message.joinRequest, options);
                if (options.oneofs)
                    object.event = "joinRequest";
            }
            if (message.playerDisconnected != null && message.hasOwnProperty("playerDisconnected")) {
                object.playerDisconnected = $root.royale.PlayerDisconnected.toObject(message.playerDisconnected, options);
                if (options.oneofs)
                    object.event = "playerDisconnected";
            }
            return object;
        };

        /**
         * Converts this ClientEvent to JSON.
         * @function toJSON
         * @memberof royale.ClientEvent
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        ClientEvent.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return ClientEvent;
    })();

    royale.ServerEvent = (function() {

        /**
         * Properties of a ServerEvent.
         * @memberof royale
         * @interface IServerEvent
         * @property {royale.IGameState|null} [gameState] ServerEvent gameState
         * @property {royale.IJoinResponse|null} [joinResponse] ServerEvent joinResponse
         */

        /**
         * Constructs a new ServerEvent.
         * @memberof royale
         * @classdesc Represents a ServerEvent.
         * @implements IServerEvent
         * @constructor
         * @param {royale.IServerEvent=} [properties] Properties to set
         */
        function ServerEvent(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * ServerEvent gameState.
         * @member {royale.IGameState|null|undefined} gameState
         * @memberof royale.ServerEvent
         * @instance
         */
        ServerEvent.prototype.gameState = null;

        /**
         * ServerEvent joinResponse.
         * @member {royale.IJoinResponse|null|undefined} joinResponse
         * @memberof royale.ServerEvent
         * @instance
         */
        ServerEvent.prototype.joinResponse = null;

        // OneOf field names bound to virtual getters and setters
        var $oneOfFields;

        /**
         * ServerEvent event.
         * @member {"gameState"|"joinResponse"|undefined} event
         * @memberof royale.ServerEvent
         * @instance
         */
        Object.defineProperty(ServerEvent.prototype, "event", {
            get: $util.oneOfGetter($oneOfFields = ["gameState", "joinResponse"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * Creates a new ServerEvent instance using the specified properties.
         * @function create
         * @memberof royale.ServerEvent
         * @static
         * @param {royale.IServerEvent=} [properties] Properties to set
         * @returns {royale.ServerEvent} ServerEvent instance
         */
        ServerEvent.create = function create(properties) {
            return new ServerEvent(properties);
        };

        /**
         * Encodes the specified ServerEvent message. Does not implicitly {@link royale.ServerEvent.verify|verify} messages.
         * @function encode
         * @memberof royale.ServerEvent
         * @static
         * @param {royale.IServerEvent} message ServerEvent message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        ServerEvent.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.gameState != null && message.hasOwnProperty("gameState"))
                $root.royale.GameState.encode(message.gameState, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
            if (message.joinResponse != null && message.hasOwnProperty("joinResponse"))
                $root.royale.JoinResponse.encode(message.joinResponse, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
            return writer;
        };

        /**
         * Encodes the specified ServerEvent message, length delimited. Does not implicitly {@link royale.ServerEvent.verify|verify} messages.
         * @function encodeDelimited
         * @memberof royale.ServerEvent
         * @static
         * @param {royale.IServerEvent} message ServerEvent message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        ServerEvent.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a ServerEvent message from the specified reader or buffer.
         * @function decode
         * @memberof royale.ServerEvent
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {royale.ServerEvent} ServerEvent
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        ServerEvent.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.royale.ServerEvent();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.gameState = $root.royale.GameState.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.joinResponse = $root.royale.JoinResponse.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        /**
         * Decodes a ServerEvent message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof royale.ServerEvent
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {royale.ServerEvent} ServerEvent
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        ServerEvent.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        /**
         * Verifies a ServerEvent message.
         * @function verify
         * @memberof royale.ServerEvent
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        ServerEvent.verify = function verify(message) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            var properties = {};
            if (message.gameState != null && message.hasOwnProperty("gameState")) {
                properties.event = 1;
                {
                    var error = $root.royale.GameState.verify(message.gameState);
                    if (error)
                        return "gameState." + error;
                }
            }
            if (message.joinResponse != null && message.hasOwnProperty("joinResponse")) {
                if (properties.event === 1)
                    return "event: multiple values";
                properties.event = 1;
                {
                    var error = $root.royale.JoinResponse.verify(message.joinResponse);
                    if (error)
                        return "joinResponse." + error;
                }
            }
            return null;
        };

        /**
         * Creates a ServerEvent message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof royale.ServerEvent
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {royale.ServerEvent} ServerEvent
         */
        ServerEvent.fromObject = function fromObject(object) {
            if (object instanceof $root.royale.ServerEvent)
                return object;
            var message = new $root.royale.ServerEvent();
            if (object.gameState != null) {
                if (typeof object.gameState !== "object")
                    throw TypeError(".royale.ServerEvent.gameState: object expected");
                message.gameState = $root.royale.GameState.fromObject(object.gameState);
            }
            if (object.joinResponse != null) {
                if (typeof object.joinResponse !== "object")
                    throw TypeError(".royale.ServerEvent.joinResponse: object expected");
                message.joinResponse = $root.royale.JoinResponse.fromObject(object.joinResponse);
            }
            return message;
        };

        /**
         * Creates a plain object from a ServerEvent message. Also converts values to other types if specified.
         * @function toObject
         * @memberof royale.ServerEvent
         * @static
         * @param {royale.ServerEvent} message ServerEvent
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        ServerEvent.toObject = function toObject(message, options) {
            if (!options)
                options = {};
            var object = {};
            if (message.gameState != null && message.hasOwnProperty("gameState")) {
                object.gameState = $root.royale.GameState.toObject(message.gameState, options);
                if (options.oneofs)
                    object.event = "gameState";
            }
            if (message.joinResponse != null && message.hasOwnProperty("joinResponse")) {
                object.joinResponse = $root.royale.JoinResponse.toObject(message.joinResponse, options);
                if (options.oneofs)
                    object.event = "joinResponse";
            }
            return object;
        };

        /**
         * Converts this ServerEvent to JSON.
         * @function toJSON
         * @memberof royale.ServerEvent
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        ServerEvent.prototype.toJSON = function toJSON() {
            return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return ServerEvent;
    })();

    return royale;
})();

module.exports = $root;
