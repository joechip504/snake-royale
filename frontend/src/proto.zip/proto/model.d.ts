import * as $protobuf from "protobufjs";
/** Namespace royale. */
export namespace royale {

    /** Direction enum. */
    enum Direction {
        UNKNOWN = 0,
        LEFT = 1,
        RIGHT = 2,
        UP = 3,
        DOWN = 4
    }

    /** Properties of a JoinRequest. */
    interface IJoinRequest {

        /** JoinRequest playerName */
        playerName?: (string|null);
    }

    /** Represents a JoinRequest. */
    class JoinRequest implements IJoinRequest {

        /**
         * Constructs a new JoinRequest.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IJoinRequest);

        /** JoinRequest playerName. */
        public playerName: string;

        /**
         * Creates a new JoinRequest instance using the specified properties.
         * @param [properties] Properties to set
         * @returns JoinRequest instance
         */
        public static create(properties?: royale.IJoinRequest): royale.JoinRequest;

        /**
         * Encodes the specified JoinRequest message. Does not implicitly {@link royale.JoinRequest.verify|verify} messages.
         * @param message JoinRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IJoinRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified JoinRequest message, length delimited. Does not implicitly {@link royale.JoinRequest.verify|verify} messages.
         * @param message JoinRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IJoinRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a JoinRequest message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns JoinRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.JoinRequest;

        /**
         * Decodes a JoinRequest message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns JoinRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.JoinRequest;

        /**
         * Verifies a JoinRequest message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a JoinRequest message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns JoinRequest
         */
        public static fromObject(object: { [k: string]: any }): royale.JoinRequest;

        /**
         * Creates a plain object from a JoinRequest message. Also converts values to other types if specified.
         * @param message JoinRequest
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.JoinRequest, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this JoinRequest to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a JoinResponse. */
    interface IJoinResponse {

        /** JoinResponse joinSuccess */
        joinSuccess?: (royale.IJoinSuccess|null);

        /** JoinResponse joinFailure */
        joinFailure?: (royale.IJoinFailure|null);
    }

    /** Represents a JoinResponse. */
    class JoinResponse implements IJoinResponse {

        /**
         * Constructs a new JoinResponse.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IJoinResponse);

        /** JoinResponse joinSuccess. */
        public joinSuccess?: (royale.IJoinSuccess|null);

        /** JoinResponse joinFailure. */
        public joinFailure?: (royale.IJoinFailure|null);

        /** JoinResponse response. */
        public response?: ("joinSuccess"|"joinFailure");

        /**
         * Creates a new JoinResponse instance using the specified properties.
         * @param [properties] Properties to set
         * @returns JoinResponse instance
         */
        public static create(properties?: royale.IJoinResponse): royale.JoinResponse;

        /**
         * Encodes the specified JoinResponse message. Does not implicitly {@link royale.JoinResponse.verify|verify} messages.
         * @param message JoinResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IJoinResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified JoinResponse message, length delimited. Does not implicitly {@link royale.JoinResponse.verify|verify} messages.
         * @param message JoinResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IJoinResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a JoinResponse message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns JoinResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.JoinResponse;

        /**
         * Decodes a JoinResponse message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns JoinResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.JoinResponse;

        /**
         * Verifies a JoinResponse message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a JoinResponse message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns JoinResponse
         */
        public static fromObject(object: { [k: string]: any }): royale.JoinResponse;

        /**
         * Creates a plain object from a JoinResponse message. Also converts values to other types if specified.
         * @param message JoinResponse
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.JoinResponse, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this JoinResponse to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a GameInfo. */
    interface IGameInfo {
    }

    /** Represents a GameInfo. */
    class GameInfo implements IGameInfo {

        /**
         * Constructs a new GameInfo.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IGameInfo);

        /**
         * Creates a new GameInfo instance using the specified properties.
         * @param [properties] Properties to set
         * @returns GameInfo instance
         */
        public static create(properties?: royale.IGameInfo): royale.GameInfo;

        /**
         * Encodes the specified GameInfo message. Does not implicitly {@link royale.GameInfo.verify|verify} messages.
         * @param message GameInfo message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IGameInfo, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified GameInfo message, length delimited. Does not implicitly {@link royale.GameInfo.verify|verify} messages.
         * @param message GameInfo message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IGameInfo, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a GameInfo message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns GameInfo
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.GameInfo;

        /**
         * Decodes a GameInfo message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns GameInfo
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.GameInfo;

        /**
         * Verifies a GameInfo message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a GameInfo message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns GameInfo
         */
        public static fromObject(object: { [k: string]: any }): royale.GameInfo;

        /**
         * Creates a plain object from a GameInfo message. Also converts values to other types if specified.
         * @param message GameInfo
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.GameInfo, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this GameInfo to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a Point. */
    interface IPoint {

        /** Point x */
        x?: (number|null);

        /** Point y */
        y?: (number|null);
    }

    /** Represents a Point. */
    class Point implements IPoint {

        /**
         * Constructs a new Point.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IPoint);

        /** Point x. */
        public x: number;

        /** Point y. */
        public y: number;

        /**
         * Creates a new Point instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Point instance
         */
        public static create(properties?: royale.IPoint): royale.Point;

        /**
         * Encodes the specified Point message. Does not implicitly {@link royale.Point.verify|verify} messages.
         * @param message Point message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IPoint, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Point message, length delimited. Does not implicitly {@link royale.Point.verify|verify} messages.
         * @param message Point message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IPoint, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a Point message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Point
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.Point;

        /**
         * Decodes a Point message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Point
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.Point;

        /**
         * Verifies a Point message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Point message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Point
         */
        public static fromObject(object: { [k: string]: any }): royale.Point;

        /**
         * Creates a plain object from a Point message. Also converts values to other types if specified.
         * @param message Point
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.Point, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Point to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a GameState. */
    interface IGameState {

        /** GameState boardWidth */
        boardWidth?: (number|null);

        /** GameState boardHeight */
        boardHeight?: (number|null);

        /** GameState idToName */
        idToName?: ({ [k: string]: string }|null);

        /** GameState players */
        players?: (royale.IPlayer[]|null);

        /** GameState food */
        food?: (royale.IPoint[]|null);
    }

    /** Represents a GameState. */
    class GameState implements IGameState {

        /**
         * Constructs a new GameState.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IGameState);

        /** GameState boardWidth. */
        public boardWidth: number;

        /** GameState boardHeight. */
        public boardHeight: number;

        /** GameState idToName. */
        public idToName: { [k: string]: string };

        /** GameState players. */
        public players: royale.IPlayer[];

        /** GameState food. */
        public food: royale.IPoint[];

        /**
         * Creates a new GameState instance using the specified properties.
         * @param [properties] Properties to set
         * @returns GameState instance
         */
        public static create(properties?: royale.IGameState): royale.GameState;

        /**
         * Encodes the specified GameState message. Does not implicitly {@link royale.GameState.verify|verify} messages.
         * @param message GameState message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IGameState, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified GameState message, length delimited. Does not implicitly {@link royale.GameState.verify|verify} messages.
         * @param message GameState message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IGameState, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a GameState message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns GameState
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.GameState;

        /**
         * Decodes a GameState message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns GameState
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.GameState;

        /**
         * Verifies a GameState message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a GameState message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns GameState
         */
        public static fromObject(object: { [k: string]: any }): royale.GameState;

        /**
         * Creates a plain object from a GameState message. Also converts values to other types if specified.
         * @param message GameState
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.GameState, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this GameState to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a JoinSuccess. */
    interface IJoinSuccess {

        /** JoinSuccess gameInfo */
        gameInfo?: (royale.IGameInfo|null);

        /** JoinSuccess playerId */
        playerId?: (number|null);
    }

    /** Represents a JoinSuccess. */
    class JoinSuccess implements IJoinSuccess {

        /**
         * Constructs a new JoinSuccess.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IJoinSuccess);

        /** JoinSuccess gameInfo. */
        public gameInfo?: (royale.IGameInfo|null);

        /** JoinSuccess playerId. */
        public playerId: number;

        /**
         * Creates a new JoinSuccess instance using the specified properties.
         * @param [properties] Properties to set
         * @returns JoinSuccess instance
         */
        public static create(properties?: royale.IJoinSuccess): royale.JoinSuccess;

        /**
         * Encodes the specified JoinSuccess message. Does not implicitly {@link royale.JoinSuccess.verify|verify} messages.
         * @param message JoinSuccess message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IJoinSuccess, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified JoinSuccess message, length delimited. Does not implicitly {@link royale.JoinSuccess.verify|verify} messages.
         * @param message JoinSuccess message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IJoinSuccess, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a JoinSuccess message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns JoinSuccess
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.JoinSuccess;

        /**
         * Decodes a JoinSuccess message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns JoinSuccess
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.JoinSuccess;

        /**
         * Verifies a JoinSuccess message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a JoinSuccess message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns JoinSuccess
         */
        public static fromObject(object: { [k: string]: any }): royale.JoinSuccess;

        /**
         * Creates a plain object from a JoinSuccess message. Also converts values to other types if specified.
         * @param message JoinSuccess
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.JoinSuccess, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this JoinSuccess to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a JoinFailure. */
    interface IJoinFailure {

        /** JoinFailure message */
        message?: (string|null);
    }

    /** Represents a JoinFailure. */
    class JoinFailure implements IJoinFailure {

        /**
         * Constructs a new JoinFailure.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IJoinFailure);

        /** JoinFailure message. */
        public message: string;

        /**
         * Creates a new JoinFailure instance using the specified properties.
         * @param [properties] Properties to set
         * @returns JoinFailure instance
         */
        public static create(properties?: royale.IJoinFailure): royale.JoinFailure;

        /**
         * Encodes the specified JoinFailure message. Does not implicitly {@link royale.JoinFailure.verify|verify} messages.
         * @param message JoinFailure message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IJoinFailure, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified JoinFailure message, length delimited. Does not implicitly {@link royale.JoinFailure.verify|verify} messages.
         * @param message JoinFailure message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IJoinFailure, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a JoinFailure message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns JoinFailure
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.JoinFailure;

        /**
         * Decodes a JoinFailure message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns JoinFailure
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.JoinFailure;

        /**
         * Verifies a JoinFailure message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a JoinFailure message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns JoinFailure
         */
        public static fromObject(object: { [k: string]: any }): royale.JoinFailure;

        /**
         * Creates a plain object from a JoinFailure message. Also converts values to other types if specified.
         * @param message JoinFailure
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.JoinFailure, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this JoinFailure to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a Player. */
    interface IPlayer {

        /** Player playerId */
        playerId?: (number|null);

        /** Player occupies */
        occupies?: (royale.IPoint[]|null);
    }

    /** Represents a Player. */
    class Player implements IPlayer {

        /**
         * Constructs a new Player.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IPlayer);

        /** Player playerId. */
        public playerId: number;

        /** Player occupies. */
        public occupies: royale.IPoint[];

        /**
         * Creates a new Player instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Player instance
         */
        public static create(properties?: royale.IPlayer): royale.Player;

        /**
         * Encodes the specified Player message. Does not implicitly {@link royale.Player.verify|verify} messages.
         * @param message Player message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IPlayer, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Player message, length delimited. Does not implicitly {@link royale.Player.verify|verify} messages.
         * @param message Player message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IPlayer, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a Player message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Player
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.Player;

        /**
         * Decodes a Player message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Player
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.Player;

        /**
         * Verifies a Player message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Player message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Player
         */
        public static fromObject(object: { [k: string]: any }): royale.Player;

        /**
         * Creates a plain object from a Player message. Also converts values to other types if specified.
         * @param message Player
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.Player, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Player to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a PlayerDisconnected. */
    interface IPlayerDisconnected {

        /** PlayerDisconnected playerName */
        playerName?: (string|null);
    }

    /** Represents a PlayerDisconnected. */
    class PlayerDisconnected implements IPlayerDisconnected {

        /**
         * Constructs a new PlayerDisconnected.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IPlayerDisconnected);

        /** PlayerDisconnected playerName. */
        public playerName: string;

        /**
         * Creates a new PlayerDisconnected instance using the specified properties.
         * @param [properties] Properties to set
         * @returns PlayerDisconnected instance
         */
        public static create(properties?: royale.IPlayerDisconnected): royale.PlayerDisconnected;

        /**
         * Encodes the specified PlayerDisconnected message. Does not implicitly {@link royale.PlayerDisconnected.verify|verify} messages.
         * @param message PlayerDisconnected message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IPlayerDisconnected, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified PlayerDisconnected message, length delimited. Does not implicitly {@link royale.PlayerDisconnected.verify|verify} messages.
         * @param message PlayerDisconnected message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IPlayerDisconnected, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a PlayerDisconnected message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns PlayerDisconnected
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.PlayerDisconnected;

        /**
         * Decodes a PlayerDisconnected message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns PlayerDisconnected
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.PlayerDisconnected;

        /**
         * Verifies a PlayerDisconnected message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a PlayerDisconnected message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns PlayerDisconnected
         */
        public static fromObject(object: { [k: string]: any }): royale.PlayerDisconnected;

        /**
         * Creates a plain object from a PlayerDisconnected message. Also converts values to other types if specified.
         * @param message PlayerDisconnected
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.PlayerDisconnected, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this PlayerDisconnected to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a MoveRequest. */
    interface IMoveRequest {

        /** MoveRequest direction */
        direction?: (royale.Direction|null);
    }

    /** Represents a MoveRequest. */
    class MoveRequest implements IMoveRequest {

        /**
         * Constructs a new MoveRequest.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IMoveRequest);

        /** MoveRequest direction. */
        public direction: royale.Direction;

        /**
         * Creates a new MoveRequest instance using the specified properties.
         * @param [properties] Properties to set
         * @returns MoveRequest instance
         */
        public static create(properties?: royale.IMoveRequest): royale.MoveRequest;

        /**
         * Encodes the specified MoveRequest message. Does not implicitly {@link royale.MoveRequest.verify|verify} messages.
         * @param message MoveRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IMoveRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified MoveRequest message, length delimited. Does not implicitly {@link royale.MoveRequest.verify|verify} messages.
         * @param message MoveRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IMoveRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a MoveRequest message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns MoveRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.MoveRequest;

        /**
         * Decodes a MoveRequest message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns MoveRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.MoveRequest;

        /**
         * Verifies a MoveRequest message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a MoveRequest message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns MoveRequest
         */
        public static fromObject(object: { [k: string]: any }): royale.MoveRequest;

        /**
         * Creates a plain object from a MoveRequest message. Also converts values to other types if specified.
         * @param message MoveRequest
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.MoveRequest, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this MoveRequest to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a ClientEvent. */
    interface IClientEvent {

        /** ClientEvent moveRequest */
        moveRequest?: (royale.IMoveRequest|null);

        /** ClientEvent joinRequest */
        joinRequest?: (royale.IJoinRequest|null);

        /** ClientEvent playerDisconnected */
        playerDisconnected?: (royale.IPlayerDisconnected|null);
    }

    /** Represents a ClientEvent. */
    class ClientEvent implements IClientEvent {

        /**
         * Constructs a new ClientEvent.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IClientEvent);

        /** ClientEvent moveRequest. */
        public moveRequest?: (royale.IMoveRequest|null);

        /** ClientEvent joinRequest. */
        public joinRequest?: (royale.IJoinRequest|null);

        /** ClientEvent playerDisconnected. */
        public playerDisconnected?: (royale.IPlayerDisconnected|null);

        /** ClientEvent event. */
        public event?: ("moveRequest"|"joinRequest"|"playerDisconnected");

        /**
         * Creates a new ClientEvent instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ClientEvent instance
         */
        public static create(properties?: royale.IClientEvent): royale.ClientEvent;

        /**
         * Encodes the specified ClientEvent message. Does not implicitly {@link royale.ClientEvent.verify|verify} messages.
         * @param message ClientEvent message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IClientEvent, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ClientEvent message, length delimited. Does not implicitly {@link royale.ClientEvent.verify|verify} messages.
         * @param message ClientEvent message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IClientEvent, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a ClientEvent message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ClientEvent
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.ClientEvent;

        /**
         * Decodes a ClientEvent message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ClientEvent
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.ClientEvent;

        /**
         * Verifies a ClientEvent message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a ClientEvent message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ClientEvent
         */
        public static fromObject(object: { [k: string]: any }): royale.ClientEvent;

        /**
         * Creates a plain object from a ClientEvent message. Also converts values to other types if specified.
         * @param message ClientEvent
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.ClientEvent, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ClientEvent to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }

    /** Properties of a ServerEvent. */
    interface IServerEvent {

        /** ServerEvent gameState */
        gameState?: (royale.IGameState|null);

        /** ServerEvent joinResponse */
        joinResponse?: (royale.IJoinResponse|null);
    }

    /** Represents a ServerEvent. */
    class ServerEvent implements IServerEvent {

        /**
         * Constructs a new ServerEvent.
         * @param [properties] Properties to set
         */
        constructor(properties?: royale.IServerEvent);

        /** ServerEvent gameState. */
        public gameState?: (royale.IGameState|null);

        /** ServerEvent joinResponse. */
        public joinResponse?: (royale.IJoinResponse|null);

        /** ServerEvent event. */
        public event?: ("gameState"|"joinResponse");

        /**
         * Creates a new ServerEvent instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ServerEvent instance
         */
        public static create(properties?: royale.IServerEvent): royale.ServerEvent;

        /**
         * Encodes the specified ServerEvent message. Does not implicitly {@link royale.ServerEvent.verify|verify} messages.
         * @param message ServerEvent message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: royale.IServerEvent, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ServerEvent message, length delimited. Does not implicitly {@link royale.ServerEvent.verify|verify} messages.
         * @param message ServerEvent message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: royale.IServerEvent, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a ServerEvent message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ServerEvent
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): royale.ServerEvent;

        /**
         * Decodes a ServerEvent message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ServerEvent
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): royale.ServerEvent;

        /**
         * Verifies a ServerEvent message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a ServerEvent message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ServerEvent
         */
        public static fromObject(object: { [k: string]: any }): royale.ServerEvent;

        /**
         * Creates a plain object from a ServerEvent message. Also converts values to other types if specified.
         * @param message ServerEvent
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: royale.ServerEvent, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ServerEvent to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };
    }
}
